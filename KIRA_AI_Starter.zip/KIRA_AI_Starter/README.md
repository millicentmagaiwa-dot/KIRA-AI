# KIRA AI — Starter project

This is the first visual Android-friendly web app prototype for KIRA.

## Important
This starter is **not connected to an AI model yet**. It demonstrates the chat interface only. The next development step is a secure backend that calls an AI provider without exposing its secret API key in the browser.

## Files
- `index.html` — app interface and starter chat interactions
- `manifest.webmanifest` — installable PWA metadata
- `sw.js` — basic offline caching

## Next steps
1. Upload these files to a private or public GitHub repository from your phone.
2. Enable GitHub Pages to publish the prototype over HTTPS.
3. Open the published URL in Chrome on Android and choose **Add to Home screen**.
4. Add a backend AI endpoint and connect the chat interface to it.
5. Add user accounts, database-backed memory, and later an SMS gateway.

Do not put AI provider API keys in `index.html` or any public repository.
